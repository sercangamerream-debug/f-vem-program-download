

ConfigACS = {}

ConfigACS.ModelsLogWebhook = "https://discord.com/api/webhooks/..."
ConfigACS.ExplosionLogWebhook = "https://discord.com/api/webhooks/..."

ConfigACS.LogBanWebhook = "https://discord.com/api/webhooks/..." --YOUR BANS/LOGS WEBHOOK
ConfigACS.AntiVPNWebhook = "https://discord.com/api/webhooks/..." -- ANTIVPN WEBHOOK

ConfigACS.ServerName = "WaweShield - Logs" --YOUR SERVER NAME

ConfigACS.Version = "v1.6.4" -- DONT TOUCH THIS

ConfigACS.License = "CRACKED"

